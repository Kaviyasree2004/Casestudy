package com.rideshare.util;

// Validates common user fields: name, email, password, mobile, city
public class UserValidator {

    private static final String NAME_REGEX = "[a-zA-Z ]+";
    private static final String EMAIL_REGEX = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
    private static final String DIGITS_ONLY = "^[6-9][0-9]{9}$";
    private static final String CITY_REGEX = "[a-zA-Z ]+";

    public static boolean isValidName(String name) {
        return ValidationUtils.validateField(name, "Name", NAME_REGEX,
                "Name must contain only letters and spaces!", 2);
    }

    public static boolean isValidEmail(String email) {
        if (ValidationUtils.isBlank(email, "Email")) return false;
        return ValidationUtils.matchesPattern(email, EMAIL_REGEX,
                "Invalid email format! (e.g., user@example.com)");
    }

    public static boolean isValidPassword(String password) {
        if (ValidationUtils.isBlank(password, "Password")) return false;
        if (!ValidationUtils.hasMinLength(password, 8, "Password")) return false;

        String[][] rules = {
            {".*[A-Z].*", "Password must contain at least one uppercase letter!"},
            {".*[a-z].*", "Password must contain at least one lowercase letter!"},
            {".*[0-9].*", "Password must contain at least one digit!"},
            {".*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?].*", "Password must contain at least one special character!"}
        };

        for (String[] rule : rules) {
            if (!ValidationUtils.matchesPattern(password, rule[0], rule[1])) return false;
        }

        return true;
    }

    public static boolean isValidMobile(String mobileStr) {
        if (ValidationUtils.isBlank(mobileStr, "Mobile number")) return false;
        if (!ValidationUtils.matchesPattern(mobileStr, DIGITS_ONLY, "Mobile number must contain only digits!")) return false;
        if (mobileStr.length() != 10) {
            System.out.println("Error: Mobile number must be exactly 10 digits!");
            return false;
        }
        return true;
    }

    public static boolean isValidCity(String city) {
        return ValidationUtils.validateField(city, "City", CITY_REGEX,
                "City must contain only letters and spaces!", 2);
    }
}
