package com.rideshare.util;

import com.rideshare.repository.Database;
import com.rideshare.model.Passenger;
import com.rideshare.model.Driver;

// Checks for duplicate emails across passengers and drivers
public class DuplicateChecker {

    public static boolean isDuplicatePassengerEmail(String email) {
        for (Passenger p : Database.passengers) {
            if (p.getEmail().equalsIgnoreCase(email)) {
                System.out.println("Error: A passenger with this email already exists!");
                return true;
            }
        }
        return false;
    }

    public static boolean isDuplicateDriverEmail(String email) {
        for (Driver d : Database.drivers) {
            if (d.getEmail().equalsIgnoreCase(email)) {
                System.out.println("Error: A driver with this email already exists!");
                return true;
            }
        }
        return false;
    }
}
